

import { useMemo, useState } from 'react'
import {
  Activity,
  BrainCircuit,
  MapPinned,
  Sparkles,
  TrendingUp,
  Users,
  Package,
} from 'lucide-react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'


const CITY_DATA = [
  { city: 'Delhi NCR', interest: 286, orders: 42, category: 'Collectibles' },
  { city: 'Mumbai', interest: 241, orders: 35, category: 'Manga' },
  { city: 'Bengaluru', interest: 218, orders: 31, category: 'Gaming' },
  { city: 'Pune', interest: 174, orders: 24, category: 'Apparel' },
  { city: 'Hyderabad', interest: 153, orders: 21, category: 'Collectibles' },
  { city: 'Chandigarh', interest: 132, orders: 19, category: 'Cosplay' },
  { city: 'Chennai', interest: 121, orders: 17, category: 'Manga' },
]

const CATEGORIES = [
  'Collectibles',
  'Manga',
  'Apparel',
  'Gaming',
  'Music',
  'Other',
]

const money = (value) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(Number(value) || 0)

const numberFormat = (value) =>
  new Intl.NumberFormat('en-IN').format(Number(value) || 0)

export function DemandPredictor() {
  const [form, setForm] = useState({
    name: 'Sakura Spirit Collectible',
    category: 'Collectibles',
    city: 'Delhi NCR',
    price: '1499',
    quantity: '100',
    interest: '180',
    views: '900',
    feedback: '4.4',
  })

  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }))
    setError('')
  }

  function predict(event) {
    event.preventDefault()
    setError('')

    const name = form.name.trim()
    const price = Number(form.price)
    const quantity = Number(form.quantity)
    const interest = Number(form.interest)
    const views = Number(form.views)
    const feedback = Number(form.feedback)

    if (!name) {
      setError('Enter a product name before calculating.')
      return
    }

    if (!Number.isFinite(price) || price <= 0) {
      setError('Enter a valid price greater than zero.')
      return
    }

    if (
      !Number.isFinite(quantity) ||
      quantity < 1 ||
      !Number.isInteger(quantity)
    ) {
      setError('Planned quantity must be a whole number greater than zero.')
      return
    }

    if (!Number.isFinite(interest) || interest < 0) {
      setError('Interest signals must be zero or greater.')
      return
    }

    if (!Number.isFinite(views) || views < 0) {
      setError('Estimated views must be zero or greater.')
      return
    }

    if (
      !Number.isFinite(feedback) ||
      feedback < 1 ||
      feedback > 5
    ) {
      setError('Feedback must be between 1 and 5.')
      return
    }

    // These are illustrative heuristic factors, not a trained model.
    const priceFactor =
      price <= 1000 ? 1.12 : price <= 2000 ? 1 : 0.78

    const engagement = Math.min(
      1.8,
      Math.max(
        0.35,
        (interest * 0.7 + views * 0.12 + feedback * 18) / 180,
      ),
    )

    const categoryFactor = {
      Collectibles: 1.15,
      Manga: 1.12,
      Apparel: 0.95,
      Gaming: 1.02,
      Music: 0.9,
      Other: 0.85,
    }[form.category] ?? 1

    const rawExpected = Math.max(
      1,
      Math.round(
        interest * 0.18 * priceFactor * engagement * categoryFactor,
      ),
    )

    // Demand cannot exceed the quantity available in this scenario.
    const expected = Math.min(quantity, rawExpected)
    const low = Math.min(expected, Math.max(0, Math.floor(expected * 0.65)))
    const high = Math.min(quantity, Math.max(expected, Math.ceil(expected * 1.4)))
    const suggestedStock = Math.min(
      quantity,
      Math.max(1, Math.ceil(expected * 0.7)),
    )

    setResult({
      name,
      category: form.category,
      city: form.city,
      price,
      quantity,
      expected,
      low,
      high,
      suggestedStock,
      revenueLow: low * price,
      revenueHigh: high * price,
      demand: expected >= 50 ? 'High' : expected >= 20 ? 'Medium' : 'Low',
    })
  }

  return (
    <div className="advanced-page animate-in">
      <div className="advanced-alert">
        <Sparkles size={18} />
        <div>
          <strong>Demo estimates only</strong>
          <p>
            Results use illustrative rules and entered assumptions. They are
            not verified market predictions or output from a trained model.
          </p>
        </div>
      </div>

      <div className="advanced-grid">
        <form className="panel advanced-card" onSubmit={predict}>
          <div className="advanced-title">
            <BrainCircuit size={24} />
            <div>
              <h2>Product demand predictor</h2>
              <p>Explore a potential product launch scenario.</p>
            </div>
          </div>

          <label className="advanced-field">
            Product name
            <input
              required
              maxLength={100}
              value={form.name}
              onChange={(event) => update('name', event.target.value)}
              placeholder="e.g. Sakura Spirit Collectible"
            />
          </label>

          <div className="form-two">
            <label className="advanced-field">
              Category
              <select
                value={form.category}
                onChange={(event) => update('category', event.target.value)}
              >
                {CATEGORIES.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>

            <label className="advanced-field">
              Target city
              <select
                value={form.city}
                onChange={(event) => update('city', event.target.value)}
              >
                {CITY_DATA.map((item) => (
                  <option key={item.city} value={item.city}>
                    {item.city}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="form-two">
            <label className="advanced-field">
              Price (₹)
              <input
                type="number"
                min="1"
                step="1"
                required
                value={form.price}
                onChange={(event) => update('price', event.target.value)}
              />
            </label>

            <label className="advanced-field">
              Planned quantity
              <input
                type="number"
                min="1"
                step="1"
                required
                value={form.quantity}
                onChange={(event) => update('quantity', event.target.value)}
              />
            </label>
          </div>

          <div className="form-two">
            <label className="advanced-field">
              Interest signals
              <input
                type="number"
                min="0"
                step="1"
                value={form.interest}
                onChange={(event) => update('interest', event.target.value)}
              />
            </label>

            <label className="advanced-field">
              Estimated views
              <input
                type="number"
                min="0"
                step="1"
                value={form.views}
                onChange={(event) => update('views', event.target.value)}
              />
            </label>
          </div>

          <label className="advanced-field">
            Average feedback (1–5)
            <input
              type="number"
              min="1"
              max="5"
              step="0.1"
              required
              value={form.feedback}
              onChange={(event) => update('feedback', event.target.value)}
            />
          </label>

          {error && (
            <p className="advanced-error" role="alert">
              {error}
            </p>
          )}

          <button className="button button-primary" type="submit">
            <BrainCircuit size={17} />
            Calculate demo estimate
          </button>
        </form>

        <section className="panel advanced-card">
          <div className="advanced-title">
            <Activity size={24} />
            <div>
              <h2>Scenario output</h2>
              <p>Calculated from your chosen inputs.</p>
            </div>
          </div>

          {!result ? (
            <div className="prediction-empty">
              <TrendingUp size={36} />
              <h3>Your estimate will appear here</h3>
              <p>
                Enter your assumptions and calculate a launch scenario.
              </p>
            </div>
          ) : (
            <>
              <div className="prediction-product">
                <span className="eyebrow">{result.category}</span>
                <h3>{result.name}</h3>
                <p>
                  <MapPinned size={15} />
                  Target market: {result.city}
                </p>
              </div>

              <span className={`demand-pill ${result.demand.toLowerCase()}`}>
                {result.demand} illustrative demand
              </span>

              <div className="prediction-number">
                <strong>{numberFormat(result.expected)}</strong>
                <span>estimated potential orders</span>
              </div>

              <div className="range-box">
                <div>
                  <span>Potential order range</span>
                  <strong>
                    {numberFormat(result.low)}–{numberFormat(result.high)}
                  </strong>
                </div>

                <div>
                  <span>Suggested initial stock</span>
                  <strong>{numberFormat(result.suggestedStock)} units</strong>
                </div>

                <div>
                  <span>Planned quantity</span>
                  <strong>{numberFormat(result.quantity)} units</strong>
                </div>

                <div>
                  <span>Possible gross sales range</span>
                  <strong>
                    {money(result.revenueLow)}–{money(result.revenueHigh)}
                  </strong>
                </div>
              </div>

              <div className="prediction-detail-row">
                <span>Assumed unit price</span>
                <strong>{money(result.price)}</strong>
              </div>

              <p className="uncertainty-note">
                The estimate is capped at your planned quantity. Gross sales
                are illustrative and do not account for costs, cancellations,
                taxes, shipping, or actual conversion rates.
              </p>
            </>
          )}
        </section>
      </div>
    </div>
  )
}

export function CityDemand() {
  const sortedCities = useMemo(
    () => [...CITY_DATA].sort((a, b) => b.interest - a.interest),
    [],
  )

  const totalInterest = sortedCities.reduce(
    (sum, city) => sum + city.interest,
    0,
  )

  const totalOrders = sortedCities.reduce(
    (sum, city) => sum + city.orders,
    0,
  )

  const maxInterest = Math.max(
    ...sortedCities.map((city) => city.interest),
    1,
  )

  const topCity = sortedCities[0]

  return (
    <div className="advanced-page animate-in">
      <div className="advanced-alert">
        <MapPinned size={18} />
        <div>
          <strong>Illustrative city data</strong>
          <p>
            These are sample figures, not verified customer locations or live
            analytics. The city rankings are based on the sample interest values
            included in this prototype.
          </p>
        </div>
      </div>

      <div className="metrics-grid city-metrics">
        <article className="metric-card">
          <div className="metric-icon accent-pink">
            <Users size={20} />
          </div>
          <span className="metric-label">Sample interest signals</span>
          <strong className="metric-value">
            {numberFormat(totalInterest)}
          </strong>
          <span className="metric-change">Illustrative data</span>
        </article>

        <article className="metric-card">
          <div className="metric-icon accent-blue">
            <Activity size={20} />
          </div>
          <span className="metric-label">Sample orders</span>
          <strong className="metric-value">
            {numberFormat(totalOrders)}
          </strong>
          <span className="metric-change">Demo activity</span>
        </article>

        <article className="metric-card">
          <div className="metric-icon accent-purple">
            <MapPinned size={20} />
          </div>
          <span className="metric-label">Cities represented</span>
          <strong className="metric-value">{sortedCities.length}</strong>
          <span className="metric-change">Sample records</span>
        </article>
      </div>

      <div className="advanced-grid">
        <section className="panel advanced-card">
          <div className="advanced-title">
            <MapPinned size={24} />
            <div>
              <h2>City demand ranking</h2>
              <p>Ranked by sample interest signals.</p>
            </div>
          </div>

          <div className="top-city-highlight">
            <span className="top-city-icon">
              <TrendingUp size={20} />
            </span>
            <div>
              <span className="eyebrow">HIGHEST SAMPLE INTEREST</span>
              <strong>{topCity.city}</strong>
              <p>
                {numberFormat(topCity.interest)} signals · {topCity.category}
              </p>
            </div>
          </div>

          <div className="city-ranking">
            {sortedCities.map((city, index) => (
              <div className="city-row" key={city.city}>
                <span className="city-rank">{index + 1}</span>

                <div className="city-main">
                  <div className="city-name-row">
                    <strong>{city.city}</strong>
                    <span>{city.category}</span>
                  </div>

                  <div
                    className="bar-track"
                    role="progressbar"
                    aria-label={`${city.city} sample interest`}
                    aria-valuemin={0}
                    aria-valuemax={maxInterest}
                    aria-valuenow={city.interest}
                  >
                    <div
                      className={`bar-fill bar-${index % 4}`}
                      style={{
                        width: `${(city.interest / maxInterest) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                <strong className="city-interest">
                  {numberFormat(city.interest)}
                </strong>
              </div>
            ))}
          </div>
        </section>

        <section className="panel advanced-card">
          <div className="advanced-title">
            <TrendingUp size={24} />
            <div>
              <h2>Interest by city</h2>
              <p>Sample signals, not geolocated analytics.</p>
            </div>
          </div>

          <div className="city-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={sortedCities}
                layout="vertical"
                margin={{ left: 4, right: 14, top: 5, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="var(--chart-grid, #e4e1ed)"
                />

                <XAxis
                  type="number"
                  stroke="var(--chart-text, #77718e)"
                  fontSize={10}
                  allowDecimals={false}
                />

                <YAxis
                  dataKey="city"
                  type="category"
                  width={90}
                  stroke="var(--chart-text, #77718e)"
                  fontSize={10}
                />

                <Tooltip
                  formatter={(value) => [
                    numberFormat(value),
                    'Interest signals',
                  ]}
                  contentStyle={{
                    background: 'var(--tooltip-bg, #ffffff)',
                    border: '1px solid var(--tooltip-border, #e4e1ed)',
                    borderRadius: 12,
                    color: 'var(--tooltip-text, #252536)',
                    boxShadow: '0 8px 24px rgba(24, 24, 40, 0.08)',
                  }}
                />

                <Bar
                  dataKey="interest"
                  name="Interest signals"
                  fill="#8b72e8"
                  radius={[0, 7, 7, 0]}
                  maxBarSize={24}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <p className="uncertainty-note">
            Connect real, consented and aggregated audience data before using
            geographic analytics to make business decisions.
          </p>
        </section>
      </div>

      <section className="panel advanced-card city-table-card">
        <div className="advanced-title">
          <Package size={23} />
          <div>
            <h2>Sample city breakdown</h2>
            <p>Compare the illustrative interest and order figures.</p>
          </div>
        </div>

        <div className="city-table-wrap">
          <table className="city-table">
            <thead>
              <tr>
                <th>City</th>
                <th>Leading category</th>
                <th>Interest signals</th>
                <th>Sample orders</th>
              </tr>
            </thead>
            <tbody>
              {sortedCities.map((city) => (
                <tr key={city.city}>
                  <td>{city.city}</td>
                  <td>{city.category}</td>
                  <td>{numberFormat(city.interest)}</td>
                  <td>{numberFormat(city.orders)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <p className="uncertainty-note">
          Sample order counts are displayed for demonstration only and are not
          linked to the demand predictor's calculations.
        </p>
      </section>
    </div>
  )
}
